Open in zed

Installation:
1. Copy Open in zed.app to /Applications
2. Open /Applications in Finder
3. Hold Command key and drag Open in zed.app to Finder toolbar
4. Click the toolbar icon to open current folder in the app

For more apps and documentation, visit:
https://github.com/sozercan/OpenInCode
