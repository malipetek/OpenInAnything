Open in tableplus

Installation:
1. Copy Open in tableplus.app to /Applications
2. Open /Applications in Finder
3. Hold Command key and drag Open in tableplus.app to Finder toolbar
4. Click the toolbar icon to open current folder in the app

For more apps and documentation, visit:
https://github.com/sozercan/OpenInCode
