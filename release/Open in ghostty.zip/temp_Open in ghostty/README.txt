Open in ghostty

Installation:
1. Copy Open in ghostty.app to /Applications
2. Open /Applications in Finder
3. Hold Command key and drag Open in ghostty.app to Finder toolbar
4. Click the toolbar icon to open current folder in the app

For more apps and documentation, visit:
https://github.com/sozercan/OpenInCode
