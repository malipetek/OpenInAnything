Open in wezterm

Installation:
1. Copy Open in wezterm.app to /Applications
2. Open /Applications in Finder
3. Hold Command key and drag Open in wezterm.app to Finder toolbar
4. Click the toolbar icon to open current folder in the app

For more apps and documentation, visit:
https://github.com/sozercan/OpenInCode
